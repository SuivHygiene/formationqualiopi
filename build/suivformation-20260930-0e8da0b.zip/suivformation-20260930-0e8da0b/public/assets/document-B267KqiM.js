import{r as t,h as i,f as B,T as H,a as E,b as _,c as y,M as W,d as z,e as X,g as V}from"./labels-IhNl7SIX.js";import{v as ee,q as k,p as te,a as se}from"./qr-DMIWNAAp.js";const ne="#1f3a68";function re(e){return typeof e=="string"&&/^#(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(e.trim())?e.trim():ne}function D(e){if(typeof e!="string")return"";const n=e.trim();return/^data:image\/(png|jpe?g|gif|webp|svg\+xml);/i.test(n)||/^https?:\/\//i.test(n)?n:""}const p=e=>e==null||String(e).trim()==="",q=(e,n="")=>p(e)?n?i`<p class="muted">${n}</p>`:"":i`<div class="pre">${String(e).trim()}</div>`,O=e=>p(e)?"":`${y(e,2)} h`,C=e=>e?[e.civilite,e.prenom,e.nom].filter(n=>!p(n)).join(" "):"",M=e=>e?[e.prenom,e.nom].filter(n=>!p(n)).join(" "):"";function Q(e){if(!e)return"";const n=new Date(String(e).replace(" ","T")+(String(e).includes("Z")?"":"Z"));return isNaN(n)?"":n.toLocaleTimeString("fr-FR",{hour:"2-digit",minute:"2-digit"}).replace(":","h")}function w(e,n){return!e&&!n?"":!n||e===n?`le ${_(e||n)}`:e?`du ${_(e)} au ${_(n)}`:`jusqu'au ${_(n)}`}function J(e=[]){const n=[...e].sort((r,l)=>`${r.date} ${r.heure_debut}`.localeCompare(`${l.date} ${l.heure_debut}`)),s=new Map;for(const r of n)s.has(r.date)||s.set(r.date,[]),s.get(r.date).push(r);return[...s.entries()].map(([r,l])=>({date:r,creneaux:l}))}function ie(e,n=[]){const s=`${E(e.heure_debut)}–${E(e.heure_fin)}`,r=String(e.heure_debut||""),l=r<"12:00"?"Matin":r<"18:00"?"Après-midi":"Soir";return n.filter(o=>{const c=String(o.heure_debut||"");return(c<"12:00"?"Matin":c<"18:00"?"Après-midi":"Soir")===l}).length>1?s:`${l} ${s}`}function Z(e){const n=J(e);return n.length?i`<ul class="creneaux">${n.map(s=>t(i`<li><strong>${B(s.date)}</strong> : ${s.creneaux.map(r=>`${E(r.heure_debut)} – ${E(r.heure_fin)}`).join(" et ")}</li>`))}</ul>`:""}function P(e){return[e.adresse,[e.code_postal,e.ville].filter(n=>!p(n)).join(" ")].filter(n=>!p(n)).join(", ")}function x(e={},n="",s="",r=""){const l=D(n),a=[e.telephone?`Tél. ${e.telephone}`:"",e.email,e.site_web].filter(o=>!p(o)).join(" · ");return i`<header class="doc-head">
    <div class="org">
      ${l?t(i`<img class="logo" src="${l}" alt="">`):""}
      <div class="org-id">
        <div class="org-nom">${e.nom||""}</div>
        ${P(e)?t(i`<div>${P(e)}</div>`):""}
        ${a?t(i`<div>${a}</div>`):""}
        ${e.siret?t(i`<div>SIRET : ${e.siret}</div>`):""}
        ${e.nda?t(i`<div>N° de déclaration d'activité : ${e.nda}</div>`):""}
        ${e.qualiopi_numero?t(i`<div>Certification Qualiopi n° ${e.qualiopi_numero}${e.qualiopi_certificateur?` (${e.qualiopi_certificateur})`:""}</div>`):""}
      </div>
    </div>
  </header>
  ${s?t(i`<h1 class="doc-titre">${s}</h1>`):""}
  ${r?t(i`<p class="doc-sous-titre">${r}</p>`):""}`}function S(e,n={}){return i`<footer class="doc-foot">
    <div class="foot-ligne">
      <span>${e.numero?`N° ${e.numero}`:""}</span>
      <span>${e.created_at?`Document émis le ${_(e.created_at)}`:""}</span>
    </div>
    ${n.mentions_documents?t(i`<div class="pre mentions">${String(n.mentions_documents).trim()}</div>`):""}
  </footer>`}function Y(e){return e?.qrVerif?i`<div class="qr-verif">
    <img src="${e.qrVerif}" alt="QR code de vérification">
    <div><strong>Vérifier l'authenticité : scannez ce code</strong>${e.verifUrl?t(i`<div class="small mono">${e.verifUrl}</div>`):""}</div>
  </div>`:""}function T(e,n,{avecDate:s=null,titre:r="Pour l'organisme de formation"}={}){const l=D(n);return i`<div class="sig-bloc">
    <div class="sig-titre">${r}</div>
    ${s?t(i`<div>${s}</div>`):""}
    <div>${e.representant_nom||""}${e.representant_qualite?`, ${e.representant_qualite}`:""}</div>
    <div class="sig-zone">${l?t(i`<img src="${l}" alt="Signature et cachet">`):""}</div>
  </div>`}const N=(e,n)=>`Fait à ${e.ville||"…………………"}, le ${_(n)||"…………………"}`;function j(e,n,s,r=""){const l=re(n?.couleur);return i`<article class="doc ${r}" style="--accent: ${l}">${t(s)}</article>`}function ae(e,n={}){const s=e.snapshot||{},r=s.organisme||{},l=e.visuels||{},a=s.session||{},o=s.formation||{},c=s.client||null,m=s.stagiaires||[],g=c?"Convention de formation professionnelle":"Convention / contrat de formation professionnelle",h=a.duree_heures??s.heures_planifiees??o.duree_heures;let d=0;const $=v=>i`<h2>Article ${++d} – ${v}</h2>`,A=i`<section class="parties">
    <p><strong>Entre les soussignés :</strong></p>
    <p><strong>${r.nom||""}</strong>${P(r)?`, ${P(r)}`:""}${r.siret?`, SIRET ${r.siret}`:""}${r.nda?`, déclaration d'activité n° ${r.nda}`:""},
      représenté par ${r.representant_nom||"…………………"}${r.representant_qualite?`, ${r.representant_qualite}`:""},
      ci-après dénommé « l'organisme de formation »,</p>
    <p>et</p>
    ${c?t(i`<p><strong>${c.raison_sociale||""}</strong>${[c.adresse,[c.code_postal,c.ville].filter(v=>!p(v)).join(" ")].filter(v=>!p(v)).length?`, ${[c.adresse,[c.code_postal,c.ville].filter(v=>!p(v)).join(" ")].filter(v=>!p(v)).join(", ")}`:""}${c.siret?`, SIRET ${c.siret}`:""}${c.contact_nom?`, représentée par ${c.contact_nom}${c.contact_fonction?`, ${c.contact_fonction}`:""}`:""},
          ci-après dénommée « le client »,</p>`):t(i`<p>${m.length?m.map(C).join(", "):"…………………"}, ci-après dénommé(e)(s) « le bénéficiaire »,</p>`)}
    <p>est conclue la présente convention, en application des articles L. 6353-1 et suivants du Code du travail.</p>
  </section>`,u=m.length?i`<table class="grille"><thead><tr><th>#</th><th>Stagiaire</th></tr></thead><tbody>${m.map((v,f)=>t(i`<tr><td class="num">${f+1}</td><td>${C(v)}</td></tr>`))}</tbody></table>`:i`<p class="muted">Liste des stagiaires communiquée ultérieurement.</p>`,L=i`
    ${t(x(r,l.logo,g,a.reference?`Réf. session : ${a.reference}`:""))}
    ${t(A)}

    ${t($("Objet"))}
    <p>La présente convention a pour objet la réalisation, par l'organisme de formation, de l'action de formation intitulée :
      <strong>« ${a.intitule||o.titre||""} »</strong>${o.code?` (code ${o.code}${o.version?`, version ${o.version}`:""})`:""}.</p>
    <h3>Objectifs</h3>
    ${t(q(o.objectifs,"Non renseignés."))}
    <h3>Programme</h3>
    ${t(q(o.contenu,"Programme annexé."))}

    ${t($("Nature et caractéristiques de l’action"))}
    <p>L'action entre dans la catégorie des actions de formation prévues à l'article L. 6313-1 du Code du travail.</p>
    <table class="kv">
      <tr><th>Durée</th><td>${O(h)}${o.duree_jours?` (${y(o.duree_jours,1)} jour(s))`:""}</td></tr>
      <tr><th>Modalité</th><td>${z[a.modalite]||a.modalite||""}</td></tr>
      <tr><th>Dates</th><td>${w(a.date_debut,a.date_fin)}</td></tr>
      <tr><th>Lieu</th><td>${a.lieu||""}</td></tr>
      ${s.formateur?t(i`<tr><th>Formateur</th><td>${M(s.formateur)}</td></tr>`):""}
      ${o.public_vise?t(i`<tr><th>Public visé</th><td class="pre">${String(o.public_vise).trim()}</td></tr>`):""}
      ${o.prerequis?t(i`<tr><th>Prérequis</th><td class="pre">${String(o.prerequis).trim()}</td></tr>`):""}
      <tr><th>Effectif</th><td>${m.length} stagiaire(s)</td></tr>
    </table>
    ${s.creneaux?.length?t(i`<h3>Calendrier</h3>${t(Z(s.creneaux))}`):""}
    <h3>Stagiaire(s)</h3>
    ${t(u)}

    ${t($("Moyens pédagogiques et techniques"))}
    ${t(q(o.methodes_pedagogiques))}
    ${t(q(o.moyens_techniques))}
    ${p(o.methodes_pedagogiques)&&p(o.moyens_techniques)?t(i`<p class="muted">Précisés dans le programme de formation.</p>`):""}

    ${t($("Modalités d’évaluation et de suivi"))}
    ${t(q(o.modalites_evaluation,"Évaluation des acquis en fin de formation."))}
    <p>L'assiduité est justifiée par des feuilles d'émargement signées par demi-journée. Une attestation de fin de formation est remise à chaque stagiaire.</p>

    ${t($("Accessibilité"))}
    ${t(q(o.accessibilite))}
    <p>Les personnes en situation de handicap sont invitées à se signaler avant l'entrée en formation${r.referent_handicap_nom?` auprès du référent handicap, ${r.referent_handicap_nom}${r.referent_handicap_email?` (${r.referent_handicap_email})`:""}`:""}, afin d'étudier les adaptations possibles.</p>

    ${t($("Dispositions financières"))}
    <table class="kv">
      <tr><th>Prix de la formation</th><td>${p(a.prix_ht)?"…………………":`${X(a.prix_ht)} HT`}</td></tr>
      <tr><th>TVA</th><td>selon régime de l'organisme</td></tr>
      ${a.financement?t(i`<tr><th>Financement</th><td>${a.financement}</td></tr>`):""}
    </table>
    <p>Le règlement est effectué selon les modalités précisées sur la facture.</p>

    ${t($("Dédit, abandon et annulation"))}
    <p>En cas de renoncement par le ${c?"client":"bénéficiaire"} à l'exécution de la présente convention, ou d'abandon en cours de formation, seules les prestations effectivement réalisées sont dues au titre de la formation professionnelle, dans les conditions prévues par les conditions générales de l'organisme.
      Toute somme éventuellement facturée au titre d'un dédit ne peut être imputée sur les fonds de la formation professionnelle continue.
      L'organisme de formation se réserve la possibilité de reporter ou d'annuler la session si les conditions pédagogiques ne sont pas réunies ; le ${c?"client":"bénéficiaire"} en est alors informé dans les meilleurs délais et aucune somme n'est due pour les prestations non réalisées.</p>
    ${c?"":t(i`<p>Conformément à l'article L. 6353-5 du Code du travail, la personne physique dispose d'un délai de rétractation de dix jours à compter de la signature du contrat, par lettre recommandée avec avis de réception.</p>`)}
    <p>Pour le surplus, il est renvoyé aux conditions générales de vente de l'organisme de formation${l.conditions_generales?", annexées à la présente convention":""}.</p>

    ${t($("Différends"))}
    <p>Les parties s'efforceront de régler à l'amiable tout différend relatif à l'exécution de la présente convention. À défaut, le litige sera porté devant les juridictions compétentes.</p>

    <p class="fait">${N(r,e.created_at)}, en deux exemplaires originaux.</p>
    <div class="signatures">
      ${t(T(r,l.signature_cachet))}
      <div class="sig-bloc">
        <div class="sig-titre">${c?"Pour le client":"Le bénéficiaire"}</div>
        <div>Date, nom, qualité, signature${c?" et cachet":""}</div>
        <div class="sig-zone"></div>
      </div>
    </div>
    ${t(S(e,r))}
    ${l.conditions_generales?t(i`<section class="annexe">
          <h1 class="doc-titre">Annexe – Conditions générales</h1>
          <div class="pre cg">${String(l.conditions_generales).trim()}</div>
        </section>`):""}`;return j(e,l,L,"doc-convention")}function oe(e,n={}){const s=e.snapshot||{},r=s.organisme||{},l=e.visuels||{},a=s.session||{},o=s.formation||{},c=s.stagiaire||{},m=s.acces||{},g=[r.referent_handicap_nom,r.referent_handicap_email,r.referent_handicap_tel].filter(d=>!p(d)).join(" – "),h=i`
    ${t(x(r,l.logo))}
    <div class="destinataire">
      <div><strong>${C(c)}</strong></div>
      ${c.entreprise?t(i`<div>${c.entreprise}</div>`):""}
    </div>
    <h1 class="doc-titre">Convocation à la formation</h1>
    <p>${c.civilite==="Mme"?"Madame":c.civilite==="M."?"Monsieur":"Madame, Monsieur"},</p>
    <p>Nous avons le plaisir de vous confirmer votre inscription à la formation
      <strong>« ${a.intitule||o.titre||""} »</strong> et vous prions de bien vouloir vous présenter aux dates et horaires suivants :</p>
    ${t(Z(s.creneaux||[])||i`<p>${w(a.date_debut,a.date_fin)}</p>`)}
    <div class="infos">
      <div><span class="lbl">Lieu</span>${a.lieu||""}</div>
      <div><span class="lbl">Modalité</span>${z[a.modalite]||a.modalite||""}</div>
      <div><span class="lbl">Durée</span>${O(s.heures_planifiees??a.duree_heures)}</div>
      ${s.formateur?t(i`<div><span class="lbl">Formateur</span>${M(s.formateur)}</div>`):""}
      ${o.public_vise?t(i`<div class="plein"><span class="lbl">Public visé</span><span class="pre">${String(o.public_vise).trim()}</span></div>`):""}
      ${o.prerequis?t(i`<div class="plein"><span class="lbl">Prérequis</span><span class="pre">${String(o.prerequis).trim()}</span></div>`):""}
    </div>

    ${m.token||m.code_session?t(i`<div class="encadre espace">
          ${n.qrPortail?t(i`<img src="${n.qrPortail}" alt="QR code d'accès à l'espace stagiaire">`):""}
          <div>
            <div class="encadre-titre">Votre espace stagiaire</div>
            <p>Scannez ce QR code avec votre téléphone pour accéder à votre espace (émargement, questionnaires, documents),
              ou rendez-vous sur :</p>
            <div class="mono">${n.portailBase||""}</div>
            <p class="mono codes">Code session : <strong>${m.code_session||""}</strong> — Code personnel : <strong>${m.code_acces||""}</strong></p>
            <p class="small">Ces codes sont personnels : ne les communiquez pas.</p>
          </div>
        </div>`):""}

    <p>Si vous êtes en situation de handicap ou avez des besoins particuliers, contactez ${g?`notre référent handicap : ${g}`:"l'organisme de formation"} avant le début de la formation afin que nous puissions étudier les adaptations nécessaires.</p>
    <p>En cas d'empêchement, merci de nous prévenir au plus tôt${r.telephone||r.email?` (${[r.telephone,r.email].filter(d=>!p(d)).join(" – ")})`:""}. Nous vous prions d'agréer nos salutations distinguées.</p>
    <div class="signatures">
      <p class="fait">${N(r,e.created_at)}</p>
      ${t(T(r,l.signature_cachet,{titre:"L'organisme de formation"}))}
    </div>
    ${t(S(e,r))}`;return j(e,l,h,"doc-convocation")}function le(e,n={}){const s=e.snapshot||{},r=s.organisme||{},l=e.visuels||{},a=s.session||{},o=s.formation||{},c=s.stagiaire||{},m=s.evaluations||[],g=m.length?i`<h2>Résultats de l'évaluation des acquis</h2>
      <table class="grille">
        <thead><tr><th>Évaluation</th><th>Moment</th><th class="num">Score</th><th class="num">%</th></tr></thead>
        <tbody>${m.map(d=>{const $=Number(d.score_max)>0?Math.round(Number(d.score)/Number(d.score_max)*100):null;return t(i`<tr><td>${d.titre||""}</td><td>${W[d.moment]||d.moment||""}</td>
            <td class="num">${y(d.score,2)} / ${y(d.score_max,2)}</td><td class="num">${$===null?"":`${$} %`}</td></tr>`)})}</tbody>
      </table>`:"",h=i`
    ${t(x(r,l.logo,"Attestation de fin de formation"))}
    <p class="corps-attest">Je soussigné(e) <strong>${r.representant_nom||"…………………"}</strong>${r.representant_qualite?`, ${r.representant_qualite}`:""}
      de l'organisme de formation <strong>${r.nom||""}</strong>, atteste que
      <strong>${C(c)}</strong>${c.entreprise?t(i`, de l'entreprise <strong>${c.entreprise}</strong>,`):""}
      a suivi la formation <strong>« ${a.intitule||o.titre||""} »</strong>
      ${w(a.date_debut,a.date_fin)}, d'une durée de <strong>${y(s.heures_realisees??0,2)} heures</strong>${p(s.heures_planifiees)?"":` (sur ${O(s.heures_planifiees)} prévues)`}.</p>
    <table class="kv">
      <tr><th>Modalité</th><td>${z[a.modalite]||a.modalite||""}</td></tr>
      ${a.lieu?t(i`<tr><th>Lieu</th><td>${a.lieu}</td></tr>`):""}
      ${s.dates_presence?.length?t(i`<tr><th>Jours de présence</th><td>${s.dates_presence.map(d=>_(d)).join(", ")}</td></tr>`):""}
    </table>
    <h2>Objectifs de la formation</h2>
    ${t(q(o.objectifs,"Non renseignés."))}
    ${t(g)}
    <p class="fait">${N(r,e.created_at)}</p>
    <div class="signatures">
      ${t(Y(n))}
      ${t(T(r,l.signature_cachet,{titre:"Signature et cachet"}))}
    </div>
    ${t(S(e,r))}`;return j(e,l,h,"doc-attestation")}function ce(e,n={}){const s=e.snapshot||{},r=s.organisme||{},l=e.visuels||{},a=s.session||{},o=s.formation||{},c=s.stagiaire||{},m=[c.nom,c.prenom].filter(d=>!p(d)).join(" "),g=(d,$)=>i`<li><span class="case">${d?"☒":"☐"}</span> ${$}</li>`,h=i`
    ${t(x(r,l.logo,"Certificat de réalisation"))}
    <div class="certificat">
      <p>Je soussigné(e) <strong>${r.representant_nom||"…………………"}</strong>, représentant légal du dispensateur de l'action concourant au développement des compétences
        <strong>${r.nom||""}</strong>,</p>
      <p>atteste que :</p>
      <p class="cert-nom"><strong>${m}</strong></p>
      <p>salarié(e) de l'entreprise <strong>${c.entreprise||"…………………"}</strong></p>
      <p>a suivi l'action <strong>${a.intitule||o.titre||""}</strong></p>
      <p>Nature de l'action concourant au développement des compétences :</p>
      <ul class="cases">
        ${t(g(!0,"action de formation"))}
        ${t(g(!1,"bilan de compétences"))}
        ${t(g(!1,"action de VAE"))}
        ${t(g(!1,"action de formation par apprentissage"))}
      </ul>
      <p>qui s'est déroulée du <strong>${_(a.date_debut)||"…………"}</strong> au <strong>${_(a.date_fin||a.date_debut)||"…………"}</strong>
        pour une durée de <strong>${y(s.heures_realisees??0,2)}</strong> heures.</p>
      <p class="engagement">Sans préjudice des délais imposés par les règles fiscales, comptables ou commerciales, je m'engage à conserver l'ensemble des pièces justificatives qui ont permis d'établir le présent certificat pendant une durée de 3 ans à compter de la fin de l'année du dernier paiement. En cas de cofinancement des fonds européens la durée de conservation est étendue conformément aux obligations conventionnelles spécifiques.</p>
      <p class="fait">${N(r,e.created_at)}</p>
    </div>
    <div class="signatures">
      ${t(Y(n))}
      ${t(T(r,l.signature_cachet,{titre:"Cachet et signature du responsable du dispensateur de formation"}))}
    </div>
    ${t(S(e,r))}`;return j(e,l,h,"doc-certificat")}const de={portail:"portail",tablette:"tablette",manuel:"saisie manuelle"};function ue(e){if(!e)return"";if(e.statut==="absent")return i`<span class="absent">Absent</span>`;if(e.statut==="absent_justifie")return i`<span class="absent">Absent justifié</span>`;const n=D(e.signature),s=Q(e.signed_at);return i`${n?t(i`<img class="sig-img" src="${n}" alt="Signature">`):t(i`<span>Présent</span>`)}
    <div class="sig-meta">${s?`signé à ${s}`:""}${e.mode?` (${de[e.mode]||e.mode})`:""}</div>`}function G(e,{doc:n=null}={}){const s=e.session||{},r=e.organisme||{},l={logo:r.logo,couleur:r.couleur,...e.visuels||{}},a=(s.inscriptions||[]).filter(u=>u.statut!=="annule"),o=new Map;for(const u of e.signatures||[])o.set(`${u.creneau_id}:${u.inscription_id}`,u);const c=new Map;for(const u of e.formateur_signatures||[])c.set(String(u.id),u);const m=J(s.creneaux||[]),g=Math.max(0,...m.map(u=>u.creneaux.length)),h=a.length?0:10,d=s.formation||{},$=m.map(u=>{const L=a.map(f=>t(i`<tr>
        <td class="stag"><strong>${[f.nom,f.prenom].filter(b=>!p(b)).join(" ")}</strong>${f.entreprise?t(i`<div class="small">${f.entreprise}</div>`):""}${f.statut==="abandon"?t(i`<div class="small">(abandon)</div>`):""}</td>
        ${u.creneaux.map(b=>t(i`<td class="sig-cell">${t(ue(b.id!=null?o.get(`${b.id}:${f.id}`):null))}</td>`))}
      </tr>`));for(let f=0;f<h;f++)L.push(t(i`<tr><td class="stag">&nbsp;</td>${u.creneaux.map(()=>t('<td class="sig-cell"></td>'))}</tr>`));const v=i`<tr class="formateur">
      <td class="stag"><strong>Formateur</strong>${s.formateur?t(i`<div class="small">${M(s.formateur)}</div>`):""}</td>
      ${u.creneaux.map(f=>{const b=f.id!=null?c.get(String(f.id)):null,R=D(b?.formateur_signature),I=Q(b?.formateur_signed_at);return t(i`<td class="sig-cell">${R?t(i`<img class="sig-img" src="${R}" alt="Signature du formateur">`):""}${I?t(i`<div class="sig-meta">signé à ${I}</div>`):""}</td>`)})}
    </tr>`;return t(i`<section class="jour">
      <h2>${B(u.date)}</h2>
      <table class="grille emargement">
        <colgroup><col class="col-stag">${u.creneaux.map(()=>t("<col>"))}</colgroup>
        <thead><tr><th>Stagiaire</th>${u.creneaux.map(f=>t(i`<th>${ie(f,u.creneaux)}</th>`))}</tr></thead>
        <tbody>${L}${t(v)}</tbody>
      </table>
    </section>`)}),A=i`
    ${t(x(r,l.logo,"Feuille d'émargement"))}
    <table class="kv">
      <tr><th>Formation</th><td>${s.intitule||d.titre||""}</td></tr>
      ${s.reference?t(i`<tr><th>Référence</th><td>${s.reference}</td></tr>`):""}
      <tr><th>Dates</th><td>${w(s.date_debut,s.date_fin)}</td></tr>
      ${s.lieu?t(i`<tr><th>Lieu</th><td>${s.lieu}</td></tr>`):""}
      ${s.formateur?t(i`<tr><th>Formateur</th><td>${M(s.formateur)}</td></tr>`):""}
      ${s.client?t(i`<tr><th>Client</th><td>${s.client.raison_sociale||""}</td></tr>`):""}
    </table>
    ${$.length?$:t(i`<p class="muted">Aucun créneau planifié.</p>`)}
    <p class="small mention-sig">Les signatures électroniques sont horodatées ; adresse IP et appareil conservés par l'organisme.</p>
    ${n?t(S(n,r)):""}`;return{html:j(n,l,A,"doc-feuille"),paysage:g>2}}function pe(e){const n=e.snapshot||{};return G({session:{...n.session||{},formation:n.formation,formateur:n.formateur,client:n.client,creneaux:n.creneaux||[],inscriptions:[]},organisme:n.organisme||{},visuels:e.visuels||{}},{doc:e})}function me(e,n={}){switch(e.type){case"convention":return{html:ae(e,n),paysage:!1};case"convocation":return{html:oe(e,n),paysage:!1};case"attestation":return{html:le(e,n),paysage:!1};case"certificat_realisation":return{html:ce(e,n),paysage:!1};case"feuille_emargement":return pe(e);default:return{html:i`<article class="doc"><p>Type de document non pris en charge : ${H[e.type]||e.type}</p></article>`,paysage:!1}}}const $e=document.getElementById("toolbar"),F=document.getElementById("docs");function fe(){const e=new URLSearchParams(location.hash.replace(/^#/,"")),n=(e.get("doc")||"").split(",").map(r=>r.trim()).filter(r=>/^\d+$/.test(r)),s=e.get("feuille");return{docs:n,feuille:s&&/^\d+$/.test(s)?s:null}}function U(e="pret"){$e.innerHTML=i`<div class="toolbar-in">
    <button type="button" id="btn-print" class="btn-print" ${e!=="pret"?t("disabled"):t("")}>Imprimer / PDF</button>
    <span class="aide">Dans la fenêtre d'impression, choisissez « Enregistrer au format PDF ».</span>
  </div>`,document.getElementById("btn-print").addEventListener("click",()=>window.print())}function ge(e){const n=e?.status===401?"Connectez-vous d'abord dans l'application, puis rouvrez ce document.":e?.status===404?"Document introuvable.":e?.status===403?"Vous n'avez pas accès à ce document.":e?.message||"Erreur lors du chargement du document.";U("erreur"),F.innerHTML=i`<div class="erreur" role="alert">${n}</div>`}async function ve(e){const n={};(e.type==="attestation"||e.type==="certificat_realisation")&&e.code_verif&&(n.verifUrl=ee(e.code_verif),n.qrVerif=await k(n.verifUrl,200));const s=e.snapshot?.acces?.token;return e.type==="convocation"&&(n.portailBase=te(),s&&(n.qrPortail=await k(se(s),220))),n}function he(e){const n=[...e.querySelectorAll("img")];return Promise.all(n.map(s=>s.complete?null:new Promise(r=>{s.addEventListener("load",r,{once:!0}),s.addEventListener("error",r,{once:!0})})))}function _e(e){document.body.classList.toggle("paysage",e)}async function K(){const{docs:e,feuille:n}=fe();U("chargement"),F.innerHTML=i`<p class="chargement">Chargement du document…</p>`;try{let s=[],r="Document";if(n){const a=await V(`/sessions/${n}/feuille-emargement`);s=[G(a)],r=`Émargement – ${a.session?.intitule||""}`}else if(e.length){const a=await Promise.all(e.map(o=>V(`/documents/${o}`)));s=await Promise.all(a.map(async o=>me(o,await ve(o)))),r=a.length===1?`${H[a[0].type]||"Document"} ${a[0].numero||""}`:`${a.length} documents – ${a[0].snapshot?.session?.intitule||""}`}else throw Object.assign(new Error("Aucun document demandé."),{status:0});const l=document.createElement("div");l.innerHTML=s.map(a=>a.html).join(""),await he(l),_e(s.some(a=>a.paysage)),F.replaceChildren(...l.childNodes),document.title=r.trim(),U("pret")}catch(s){console.error(s),ge(s)}}window.addEventListener("hashchange",K);K();
