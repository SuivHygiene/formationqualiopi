import{h as a,K as G,r as n,L as R,t as J,b as $,d as X,v as Z,M as D,x as W,T as ee,m as j,f as te,a as z}from"./labels-IhNl7SIX.js";/* empty css               */import{t as I,T,a as se,n as q,b as O,s as ae,o as ne,r as re,v as ie,c as oe,f as ce,E as le,d as de,p as k,g as ue,e as pe,h as me,i as fe}from"./logic-BVPewQDM.js";import{s as be}from"./signature-C6q-iuPp.js";const m=document.getElementById("app");let h=null,p=null,_=null;function he(){try{const e=localStorage.getItem(T);return e&&se.test(e)?e:null}catch{return null}}function M(e){h=e;try{localStorage.setItem(T,e)}catch{}}function V(){h=null,p=null;try{localStorage.removeItem(T)}catch{}}const S=(e,t,s)=>R(e,t,s,{"X-Access-Token":h}),ve=e=>e?e.charAt(0).toUpperCase()+e.slice(1):"",x=e=>ve(te(e)),H=e=>`${z(e.heure_debut)}–${z(e.heure_fin)}`;function U(e){const t=ae(e?.couleur),s=document.documentElement.style;t?(s.setProperty("--primary",t),s.setProperty("--on-primary",ne(t)),document.querySelector('meta[name="theme-color"]')?.setAttribute("content",t)):(s.removeProperty("--primary"),s.removeProperty("--on-primary"))}function ge(e){const t=String(e||"");return/^data:image\/(png|jpe?g|webp|gif|svg\+xml)[;,]/i.test(t)||/^https:\/\//i.test(t)?t:""}function C(e){document.title=e?`${e} — Espace stagiaire`:"Espace stagiaire"}function $e(e="Chargement…"){m.innerHTML=a`<div class="pt-shell"><p class="loader" role="status">${e}</p></div>`}function E(e="",t="error"){K(),U(null),C("Connexion");const s=new URLSearchParams(location.search),r=q(s.get("s"));m.innerHTML=a`<main class="auth-page">
    <div class="auth-card">
      <h1>Espace stagiaire</h1>
      <p class="sub">Émargement, questionnaires et documents de votre formation.</p>
      <div aria-live="polite" id="login-msg">${e?n(a`<div class="alert alert-${t==="error"?"error":"info"}">${e}</div>`):""}</div>
      <form novalidate>
        <div class="field">
          <label for="code_session">Code session</label>
          <input id="code_session" name="code_session" class="pt-code" autocomplete="off" autocapitalize="characters"
            spellcheck="false" maxlength="6" required value="${r}" aria-describedby="help_session">
          <small id="help_session">6 caractères, affiché en salle ou sur votre convocation.</small>
        </div>
        <div class="field">
          <label for="code_acces">Code personnel</label>
          <input id="code_acces" name="code_acces" class="pt-code" inputmode="numeric" pattern="[0-9]*" autocomplete="one-time-code"
            maxlength="6" required aria-describedby="help_acces">
          <small id="help_acces">6 chiffres, indiqué sur votre convocation.</small>
        </div>
        <button type="submit" class="btn btn-primary pt-btn-block">Accéder à ma formation</button>
      </form>
    </div>
  </main>`;const c=m.querySelector("form"),i=c.elements.code_session,l=c.elements.code_acces,f=m.querySelector("#login-msg");i.addEventListener("input",()=>{const d=q(i.value);d!==i.value&&(i.value=d)}),l.addEventListener("input",()=>{const d=O(l.value);d!==l.value&&(l.value=d)}),setTimeout(()=>(r.length===6?l:i).focus(),30),c.addEventListener("submit",async d=>{d.preventDefault();const o=q(i.value),u=O(l.value);if(i.classList.toggle("invalid",o.length!==6),l.classList.toggle("invalid",u.length!==6),o.length!==6||u.length!==6){f.innerHTML=a`<div class="alert alert-error">Saisissez le code session (6 caractères) et votre code personnel (6 chiffres).</div>`;return}const v=c.querySelector("[type=submit]");v.disabled=!0,f.innerHTML="";try{const b=await R("POST","/portail/connexion",{code_session:o,code_acces:u});M(b.token),location.search&&history.replaceState(null,"",location.pathname),await w()}catch(b){const F=b.status===401?"Codes incorrects. Vérifiez votre convocation ou demandez-les au formateur.":b.status===429?"Trop de tentatives. Patientez quelques minutes avant de réessayer.":b.message;f.innerHTML=a`<div class="alert alert-error">${F}</div>`,v.disabled=!1}})}async function A(){return p=await S("GET","/portail/moi"),U(p.organisme),p}function y(e){return e instanceof G&&e.status===401?(V(),E("Votre lien n’est plus valide. Connectez-vous avec vos codes."),!0):!1}async function w(){$e();try{await A()}catch(e){if(y(e))return;m.innerHTML=a`<div class="pt-shell"><div class="alert alert-error" role="alert">${e.message}</div>
      <button class="btn btn-primary pt-btn-block" data-retry>Réessayer</button></div>`,m.querySelector("[data-retry]").addEventListener("click",w);return}Y(),ye()}function ye(){K(),_=setInterval(async()=>{if(!(document.hidden||Q().name!=="home"||document.querySelector(".pt-sheet")))try{await A(),L({keepScroll:!0})}catch(e){y(e)}},6e4)}function K(){_&&clearInterval(_),_=null}function Q(){const e=/^#q=(\d+)$/.exec(location.hash);return e?{name:"questionnaire",id:e[1]}:{name:"home"}}function Y(){if(!h)return E();const e=Q();e.name==="questionnaire"?Me(e.id):L()}window.addEventListener("hashchange",()=>{const e=I(location.hash);if(e){M(e),history.replaceState(null,"",location.pathname+location.search),w();return}h&&p&&Y()});function B(){const e=p.organisme||{},t=ge(e.logo);return a`<header class="pt-header">
    ${t?n(a`<img class="pt-logo" src="${t}" alt="">`):""}
    <span class="pt-org">${e.nom||"Organisme de formation"}</span>
  </header>`}function _e(e){const t=de(e);return t?a`<section class="pt-now" aria-labelledby="now-title">
    <h2 id="now-title">Signature ouverte</h2>
    <p>${x(t.date)}<br><strong>${k(t.heure_debut)} ${H(t)}</strong></p>
    <button type="button" class="btn pt-btn-block pt-btn-light" data-sign="${t.id}">Signer ma présence</button>
  </section>`:""}function Se(e,t){const s=me(e,t);if(s.key==="signe"){const r=fe(e.signed_at);return a`<span class="badge badge-green">✔ Signé${r?` à ${r}`:""}</span>`}return s.key==="a_signer"?a`<button type="button" class="btn btn-primary" data-sign="${e.id}">À signer</button>`:a`<span class="badge badge-${s.tone}">${s.label}</span>`}function Le(){const e=ue(p.creneaux),t=pe(),s=e.length?e.map(r=>a`<div class="pt-day ${r.date===t?"is-today":""}">
            <h3>${x(r.date)}${r.date===t?n(' <span class="badge badge-blue">Aujourd’hui</span>'):""}</h3>
            <ul class="pt-list">${n(r.creneaux.map(c=>a`<li class="pt-row">
                    <span class="pt-row-main"><strong>${k(c.heure_debut)}</strong> <span class="muted">${H(c)}</span></span>
                    <span class="pt-row-side">${n(Se(c,t))}</span>
                  </li>`).join(""))}</ul>
          </div>`).join(""):a`<p class="muted">Aucun créneau planifié pour le moment.</p>`;return a`<section class="card" aria-labelledby="sec-emarg">
    <h2 id="sec-emarg">Émargement</h2>
    <p class="muted pt-help">La signature est possible de 30 minutes avant le début jusqu’à 1 heure après la fin de chaque demi-journée. Passé ce délai, adressez-vous au formateur.</p>
    ${n(s)}
  </section>`}function Ee(){const e=p.questionnaires||[],t=e.length?a`<ul class="pt-list">${n(e.map(s=>a`<li class="pt-row">
              <span class="pt-row-main"><strong>${s.titre}</strong><br><small>${D[s.moment]||W[s.type]||""}</small></span>
              <span class="pt-row-side">${s.submitted_at?n(a`<a class="badge badge-green pt-link-badge" href="#q=${s.id}">Répondu le ${$(s.submitted_at)}</a>`):n(a`<a class="btn btn-primary" href="#q=${s.id}">Répondre</a>`)}</span>
            </li>`).join(""))}</ul>`:a`<p class="muted">Aucun questionnaire à remplir pour le moment.</p>`;return a`<section class="card" aria-labelledby="sec-quest"><h2 id="sec-quest">Questionnaires</h2>${n(t)}</section>`}function we(){const e=p.documents||[],t=e.length?a`<ul class="pt-list">${n(e.map(s=>a`<li class="pt-row">
              <span class="pt-row-main"><strong>${ee[s.type]||s.type}</strong><br><small>N° ${s.numero} · émis le ${$(s.created_at)}</small></span>
              <span class="pt-row-side"><a class="btn" href="/verification.html#${s.code_verif}">Vérifier</a></span>
            </li>`).join(""))}</ul>`:a`<p class="muted">Aucun document émis pour le moment.</p>`;return a`<section class="card" aria-labelledby="sec-docs">
    <h2 id="sec-docs">Mes documents</h2>
    ${n(t)}
    <p class="muted pt-help">Les documents (convocation, attestation, certificat de réalisation) vous sont remis directement par l’organisme de formation. Le lien « Vérifier » permet à toute personne de contrôler leur authenticité.</p>
  </section>`}function qe(){const e=p.organisme||{},s=e.referent_handicap_nom||e.referent_handicap_email||e.referent_handicap_tel?a`<p>Votre référent handicap${e.referent_handicap_nom?n(a` : <strong>${e.referent_handicap_nom}</strong>`):""}</p>
      <div class="pt-contact">
        ${e.referent_handicap_tel?n(a`<a class="btn" href="tel:${String(e.referent_handicap_tel).replace(/[^\d+]/g,"")}">📞 ${e.referent_handicap_tel}</a>`):""}
        ${e.referent_handicap_email?n(a`<a class="btn" href="mailto:${e.referent_handicap_email}">✉ ${e.referent_handicap_email}</a>`):""}
      </div>`:a`<p>Signalez-le à votre formateur ou à l’organisme de formation.</p>`;return a`<section class="card" aria-labelledby="sec-aide">
    <h2 id="sec-aide">Besoin d’aide / situation de handicap</h2>
    <p class="muted">Un besoin d’adaptation (accessibilité, rythme, supports…) ? Nous en tenons compte, en toute confidentialité.</p>
    ${n(s)}
  </section>`}function L({keepScroll:e=!1}={}){const t=window.scrollY,s=p.session||{};C(s.intitule);const r=s.date_debut&&s.date_fin&&s.date_debut!==s.date_fin?`Du ${$(s.date_debut)} au ${$(s.date_fin)}`:s.date_debut?`Le ${$(s.date_debut)}`:"";m.innerHTML=a`<div class="pt-shell">
    ${n(B())}
    <main>
      <h1 class="pt-hello">Bonjour ${p.stagiaire?.prenom||""}</h1>
      ${n(_e(p.creneaux))}
      <section class="card pt-formation" aria-labelledby="sec-form">
        <h2 id="sec-form">${s.intitule}</h2>
        ${s.statut==="annulee"?n('<div class="alert alert-error">Cette session a été annulée.</div>'):""}
        <dl class="pt-info">
          ${r?n(a`<dt>Dates</dt><dd>${r}</dd>`):""}
          ${s.lieu?n(a`<dt>Lieu</dt><dd>${s.lieu}</dd>`):""}
          ${s.modalite?n(a`<dt>Modalité</dt><dd>${X[s.modalite]||s.modalite}</dd>`):""}
          ${s.formateur?n(a`<dt>Formateur</dt><dd>${s.formateur}</dd>`):""}
        </dl>
      </section>
      ${n(Le())}
      ${n(Ee())}
      ${n(we())}
      ${n(qe())}
      <div class="pt-footer">
        <button type="button" class="btn btn-ghost" data-logout>Se déconnecter de cet appareil</button>
      </div>
    </main>
  </div>`,m.querySelectorAll("[data-sign]").forEach(c=>c.addEventListener("click",()=>{const i=p.creneaux.find(l=>String(l.id)===c.dataset.sign);i&&Te(i)})),m.querySelector("[data-logout]").addEventListener("click",async()=>{await Z("Vous devrez ressaisir vos codes pour revenir sur cet appareil.",{ok:"Se déconnecter"})&&(V(),E("Vous êtes déconnecté de cet appareil.","info"))}),e&&window.scrollTo(0,t)}function Te(e){const t=document.createElement("div");t.className="pt-sheet",t.setAttribute("role","dialog"),t.setAttribute("aria-modal","true"),t.setAttribute("aria-labelledby","sig-title"),t.innerHTML=a`<div class="pt-sheet-inner">
    <div class="pt-sheet-head">
      <h2 id="sig-title">Signer ma présence</h2>
      <button type="button" class="icon-btn pt-close" data-cancel aria-label="Fermer">✕</button>
    </div>
    <p>${x(e.date)} — <strong>${k(e.heure_debut)} ${H(e)}</strong></p>
    <p class="muted">${p.stagiaire?.prenom} ${p.stagiaire?.nom}, signez dans le cadre ci-dessous avec le doigt.</p>
    <canvas class="signature-box pt-sig" aria-label="Zone de signature"></canvas>
    <div class="pt-sig-msg" aria-live="assertive"></div>
    <div class="pt-sheet-actions">
      <button type="button" class="btn" data-clear>Effacer</button>
      <button type="button" class="btn btn-primary" data-ok>Valider ma signature</button>
    </div>
  </div>`,document.body.appendChild(t),document.body.classList.add("no-scroll");const s=t.querySelector("canvas"),r=be(s),c=t.querySelector(".pt-sig-msg"),i=()=>r.resize();window.addEventListener("resize",i);const l=u=>u.key==="Escape"&&d();document.addEventListener("keydown",l);const f=document.activeElement;function d(){window.removeEventListener("resize",i),document.removeEventListener("keydown",l),t.remove(),document.body.classList.remove("no-scroll"),f?.focus?.()}t.querySelector("[data-cancel]").addEventListener("click",d),t.querySelector("[data-clear]").addEventListener("click",()=>{r.clear(),c.textContent=""});const o=t.querySelector("[data-ok]");o.addEventListener("click",async()=>{if(r.isEmpty()){c.innerHTML=a`<div class="alert alert-error">Veuillez signer dans le cadre avant de valider.</div>`;return}o.disabled=!0,c.textContent="Envoi…";try{p=await S("POST","/portail/emargement",{creneau_id:e.id,signature:r.toDataURL()}),d(),L({keepScroll:!0}),j("Présence enregistrée. Merci !","success")}catch(u){if(u.status===401){d(),y(u);return}if(u.status===409){d(),j(u.message,"info");try{await A(),L({keepScroll:!0})}catch{}return}c.innerHTML=a`<div class="alert alert-error">${u.message}</div>`,o.disabled=!1}}),setTimeout(()=>t.querySelector("[data-ok]").focus(),30)}function ke(e,t){const s=ce(e.id),r=`qf_${e.id}`,c=e.obligatoire?n(' <span class="req" aria-hidden="true">*</span><span class="sr-only">(obligatoire)</span>'):"",i=a`<div class="field-error" id="err_${e.id}" data-error="${e.id}" aria-live="polite"></div>`,l=a`<span class="pt-qnum">${t+1}.</span> ${e.libelle}${c}`,f=(o,u,v,b="")=>a`<label class="pt-choice ${b}"><input type="${o}" name="${s}" value="${u}"><span>${v}</span></label>`;let d="";switch(e.type){case"echelle":d=a`<div class="pt-scale">${n(le.map(([o,u])=>a`<label class="pt-scale-item"><input type="radio" name="${s}" value="${o}"><span><b>${o}</b><small>${u}</small></span></label>`).join(""))}</div>`;break;case"oui_non":d=a`<div class="pt-yesno">${n(f("radio","oui","Oui")+f("radio","non","Non"))}</div>`;break;case"choix_unique":d=a`<div class="pt-choices">${n((e.options||[]).map((o,u)=>f("radio",u,o)).join(""))}</div>`;break;case"choix_multiple":d=a`<p class="muted pt-help">Plusieurs réponses possibles.</p><div class="pt-choices">${n((e.options||[]).map((o,u)=>f("checkbox",u,o)).join(""))}</div>`;break;default:return a`<div class="card pt-q" data-q="${e.id}">
        <label for="${r}" class="pt-q-title">${n(l)}</label>
        <textarea id="${r}" name="${s}" rows="4" maxlength="5000" aria-describedby="err_${e.id}"></textarea>
        ${n(i)}
      </div>`}return a`<fieldset class="card pt-q" data-q="${e.id}" aria-describedby="err_${e.id}">
    <legend class="pt-q-title">${n(l)}</legend>
    ${n(d)}
    ${n(i)}
  </fieldset>`}function P(e,t){e.querySelectorAll(".pt-q").forEach(r=>r.classList.remove("pt-q-invalid")),e.querySelectorAll(".field-error").forEach(r=>r.textContent="");let s=null;for(const[r,c]of Object.entries(t||{})){const i=e.querySelector(`[data-q="${r}"]`);i&&(i.classList.add("pt-q-invalid"),i.querySelector(".field-error").textContent=c,s||=i)}s&&(s.scrollIntoView?.({behavior:"smooth",block:"center"}),s.querySelector("input, textarea")?.focus({preventScroll:!0}))}function N(e){const t=e.reponse||{},s=t.score_max?a`<p class="pt-score">Votre score : <strong>${Number(t.score)} / ${Number(t.score_max)}</strong></p>`:"";return a`<section class="card pt-merci" role="status">
    <div class="pt-merci-icon" aria-hidden="true">✔</div>
    <h2>Merci pour vos réponses !</h2>
    <p class="muted">Envoyées le ${$(t.submitted_at)}.</p>
    ${n(s)}
    <a class="btn btn-primary pt-btn-block" href="#">Retour à l’accueil</a>
  </section>`}function g(e,t){return a`<div class="pt-shell">
    ${n(B())}
    <main>
      <a class="btn btn-ghost pt-back" href="#">← Retour</a>
      <h1>${e?e.titre:"Questionnaire"}</h1>
      ${e?n(a`<p class="muted">${D[e.moment]||""}</p>`):""}
      ${n(t)}
    </main>
  </div>`}async function Me(e){window.scrollTo(0,0),m.innerHTML=g(null,a`<p class="loader" role="status">Chargement…</p>`);let t;try{t=await S("GET",`/portail/questionnaires/${e}`)}catch(i){if(y(i))return;m.innerHTML=g(null,a`<div class="alert alert-error" role="alert">${i.message}</div>`);return}if(C(t.titre),t.reponse){m.innerHTML=g(t,N(t));return}if(!t.ouvert){m.innerHTML=g(t,a`<div class="alert alert-info">Ce questionnaire est fermé.</div>`);return}const s=t.questions||[];m.innerHTML=g(t,a`<p class="muted pt-help">Les questions marquées d’un <span class="req">*</span> sont obligatoires.</p>
    <form novalidate class="pt-form">
      ${n(s.map(ke).join(""))}
      <div class="pt-form-msg" aria-live="assertive"></div>
      <button type="submit" class="btn btn-primary pt-btn-block">Envoyer mes réponses</button>
    </form>`);const r=m.querySelector("form"),c=r.querySelector(".pt-form-msg");r.addEventListener("change",i=>{const l=i.target.closest(".pt-q");l?.classList.contains("pt-q-invalid")&&(l.classList.remove("pt-q-invalid"),l.querySelector(".field-error").textContent="")}),r.addEventListener("submit",async i=>{i.preventDefault();const l=re(r,s),f=ie(s,l);if(Object.keys(f).length){c.innerHTML=a`<div class="alert alert-error">Merci de répondre à toutes les questions obligatoires.</div>`,P(r,f);return}c.innerHTML="";const d=r.querySelector("[type=submit]");d.disabled=!0;try{const o=await S("POST",`/portail/questionnaires/${t.id}`,{answers:oe(l)}),u=p?.questionnaires?.find(v=>String(v.id)===String(t.id));u&&(u.submitted_at=o.reponse?.submitted_at||new Date().toISOString()),m.innerHTML=g(o,N(o)),window.scrollTo(0,0)}catch(o){if(y(o))return;d.disabled=!1,c.innerHTML=a`<div class="alert alert-error">${o.message}</div>`,o.fields&&Object.keys(o.fields).length?P(r,o.fields):J(o)}})}function xe(){const e=I(location.hash);if(e?(M(e),history.replaceState(null,"",location.pathname+location.search)):h=he(),!h)return E();w()}xe();
