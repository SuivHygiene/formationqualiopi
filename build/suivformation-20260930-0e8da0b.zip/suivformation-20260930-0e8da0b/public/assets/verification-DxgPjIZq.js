import{h as i,r as c,L as v,b as o,T as h}from"./labels-IhNl7SIX.js";/* empty css               */import{j as d,k as u}from"./logic-BVPewQDM.js";const l=document.getElementById("app");function n(e=""){return i`<section class="card">
    <h2>Vérifier un document</h2>
    <p class="muted">Saisissez le code de vérification (16 caractères) imprimé sur le document ou lu dans son QR code.</p>
    <form class="vf-form" novalidate>
      <label for="vf-code" class="sr-only">Code de vérification</label>
      <input id="vf-code" name="code" autocomplete="off" autocapitalize="none" spellcheck="false" maxlength="24" value="${e}" placeholder="ex. ab12cd34ef56gh78" aria-describedby="vf-err">
      <button type="submit" class="btn btn-primary">Vérifier</button>
    </form>
    <div id="vf-err" class="field-error" aria-live="polite"></div>
  </section>`}function r(e){l.innerHTML=i`<div class="pt-shell">
    <header class="pt-header"><span class="pt-org">Vérification de document</span></header>
    <main><div aria-live="polite" id="vf-result">${c(e)}</div></main>
  </div>`;const t=l.querySelector(".vf-form");t?.addEventListener("submit",s=>{s.preventDefault();const a=d(t.elements.code.value);if(!u(a)){l.querySelector("#vf-err").textContent="Le code doit comporter 16 lettres ou chiffres.",t.elements.code.classList.add("invalid"),t.elements.code.focus();return}location.hash==="#"+a?m(a):location.hash=a})}function b(e){const t=e.dates?.debut&&e.dates?.fin&&e.dates.debut!==e.dates.fin?`Du ${o(e.dates.debut)} au ${o(e.dates.fin)}`:e.dates?.debut?o(e.dates.debut):"",s=[["Document",h[e.type]||e.type],["Numéro",e.numero],["Émis le",o(e.emis_le)],["Organisme",e.organisme?.nom],["N° de déclaration d’activité",e.organisme?.nda],["Formation",e.formation],["Dates",t],["Stagiaire",e.stagiaire],["Heures réalisées",e.heures_realisees!=null&&e.heures_realisees!==""?`${Number(e.heures_realisees).toLocaleString("fr-FR")} h`:""]].filter(([,a])=>a!=null&&a!=="");return i`<div class="vf-banner vf-ok" role="status">
      <span class="vf-icon" aria-hidden="true">✔</span>
      <div><h2>Document authentique</h2><p>Ce document a bien été émis par l’organisme indiqué ci-dessous.</p></div>
    </div>
    <section class="card">
      <h2>Détails du document</h2>
      <dl class="pt-info">${c(s.map(([a,p])=>i`<dt>${a}</dt><dd>${p}</dd>`).join(""))}</dl>
      <p class="muted pt-help" style="margin-top:12px">Pour protéger la vie privée, seule l’initiale du nom du stagiaire est affichée. Comparez ces informations avec celles du document présenté.</p>
    </section>`}async function m(e){document.title="Vérification de document",r(i`<p class="loader" role="status">Vérification en cours…</p>`);try{const t=await v("GET","/verification/"+encodeURIComponent(e));if(!t?.valide)throw Object.assign(new Error("invalide"),{status:404});r(b(t)+n())}catch(t){const s=t.status===404?i`<div class="vf-banner vf-ko" role="alert">
            <span class="vf-icon" aria-hidden="true">✖</span>
            <div><h2>Document introuvable</h2><p>Ce document n’a pas été émis par cet outil ou le code est erroné.</p></div>
          </div>`:t.status===429?i`<div class="alert alert-error" role="alert">Trop de vérifications depuis votre connexion. Réessayez dans quelques minutes.</div>`:i`<div class="alert alert-error" role="alert">${t.message||"Vérification impossible pour le moment."}</div>`;r(s+n(e))}}function f(){const e=d(location.hash);if(!e)return r(n());if(!u(e))return r(i`<div class="vf-banner vf-ko" role="alert">
        <span class="vf-icon" aria-hidden="true">✖</span>
        <div><h2>Document introuvable</h2><p>Ce document n’a pas été émis par cet outil ou le code est erroné.</p></div>
      </div>`+n(e));m(e)}window.addEventListener("hashchange",f);f();
